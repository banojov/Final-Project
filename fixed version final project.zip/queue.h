#ifndef queue_h
#define queue_h

#include "iterator.h"

using namespace QueueProject;
 
namespace QueueProject{
    template<class Q>
    class Queue{
    public:
      typedef List<Q> Iterator;
      Queue();
      Queue(const Queue<Q>& aQueue);
      Queue<Q>& operator= (const Queue<Q>& rightside);
      virtual ~Queue();
      void add(Q item);
      Q remove();
      bool isEmpty() const;

      Iterator begin() const{return Iterator(front);}
      Iterator end() const{return Iterator();}
    private:
      Node<Q> *front; //the head of list
      Node<Q> *back; //the other end of the list items added at the end
    };
}

#endif //queue_h

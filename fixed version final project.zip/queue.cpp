#include <iostream>
#include <cstdlib>
#include <cstddef>
#include "queue.h"
using std::cout;
using namespace QueueProject;

namespace QueueProject{
  template<class Q>
 Queue<Q>::Queue() : front(NULL),back(NULL)
  {
    //intentionally empty
  }
  template<class Q>
  bool Queue<Q>::isEmpty()const{
    return(back==NULL);
  }
  template <class Q>
  Queue<Q>::Queue(const Queue<Q>& aQueue){
    if(aQueue.isEmpty())
    front=back=NULL;
    else
    {
      Node<Q> *temp=aQueue.front;
      //temp moves from the front to the back
      back=new Node<Q>(temp->getdata(),NULL);
      front=back;
      //node created and filled with data
      //New nodes added after the first one
      temp=temp->getlink(); //temp now points to second
      while(temp!=NULL)
      {
        back->setlink(new Node<Q>(temp->getdata(),NULL));
        back=back->getlink();
        temp=temp->getlink();
      }
        //back->link == NULL
    }
  }
  template<class Q>
  Queue<Q>& Queue<Q>::operator=(const Queue<Q>& rightside){
    if(front==rightside.front) //if the queues are the same
      return *this;
    else
    {
      Q next;
      while(! isEmpty())
        next=remove();
    }
    if(rightside.isEmpty())
    {
      front=back=NULL;
      return *this;
    }
    else
    {
      Node<Q> *temp=rightside.front; //moves through the nodes
      back=new Node<Q>(temp->getdata(),NULL);
      front=back;
      //frist node filled ,other nodes after this one
      temp=temp->getlink(); //points to second
      while(temp != NULL)
      {
        back->setlink(new Node<Q>(temp->getdata(),NULL));
        back= back->getlink();
        temp=temp->getlink();
        }
          return *this;
      }
  }

  template<class Q>
  Queue<Q>::~Queue(){
    Q next;
    while(! isEmpty())
      next=remove(); //calls delete
  }

  //template<class Q>
  //bool Queue<Q>::isEmpty()const
  //{
    //return (back == NULL);
  //}
  //  template<class Q>
    //Queue<Q>::Queue():front(NULL),back(NULL)
    //{
    //intentionally empty
    //}
  template<class Q>
  void Queue<Q>::add(Q item)
  {
    if(isEmpty())
    front=back=new Node<Q>(item,NULL); //front and back are set to point to the node only
    else
    {
      back->setlink(new Node<Q>(item, NULL));
      back=back->getlink();
    }
  }
  template<class Q>
  Q Queue<Q>::remove()
    {
      if(isEmpty())
      {
        cout << "Empty Queue,can't remove from an empty Queue. \n ";
        exit(1);
      }
  Q result=front->getdata();
  Node<Q> *empty;
  empty=front;
  front=front-> getlink();
  if(front==NULL)
    back=NULL;
    delete empty;

    return result;
  }
};

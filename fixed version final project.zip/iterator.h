#ifndef iterator_h
#define iterator_h

#include <iostream>
#include <cstdlib>

namespace QueueProject{
   template <class Q>
   class Node
   {
   public:
     Node (Q thedata, Node<Q>* thelink): data(thedata),link(thelink){}
     Node<Q>* getlink()const
     {
       return link;
     }
     const Q& getdata()const
     {
       return data;
     }
   void setdata(const Q& thedata)
   {
     data=thedata;
   }
    void setlink(Node<Q>* pointer)
    {
      link=pointer;
    }
private:
  Q data;
  Node<Q> *link;
};

template<class Q>
class List{
public:
  List():current(NULL) {}
  List(Node<Q>* initial):current(initial){}
  const Q& operator *()const
  {
    return current->getdata();
    //this is current != null
  }
  List& operator++()
  {
    current=current->getlink();
    return *this;
  }
  List operator++(int)
  {
    List startVersion(current);
    current=current->getlink();
    return startVersion;
  }
  bool operator==(const List& rightside)const
  {
    return (current == rightside.current);
  }
  bool operator != (const List& rightside)const
  {
    return(current != rightside.current);
  }
private:
  Node<Q> *current;
  };
}
#endif //iterator_h

#include <iostream>
#include "queue.h"
#include "queue.cpp"
#include "iterator.h"

using std::cin;
using std::cout;
using std::endl;

using namespace QueueProject;

int main(){
  char next,ans;
  do{
    Queue<char> t;
    cout<< "Enter a line of text:\n";
    cin.get(next);
    while(next != '\n')
    {
      t.add(next);
      cin.get(next);
    }
    cout << "You entered: \n";
    Queue<char>::Iterator i;
    for(i=t.begin();i != t.end();i++)
    cout<< *i << endl;

    cout << "Again (y/n): " ;
    cin >>ans;
    cin.ignore(10000, '\n');

  }while(ans != 'n' && ans != 'N');

  return 0;
}
